This program allows the user to clock in and out of a program. It also allows 
employees who are managers to override past emlpoyees time records based on
Date and Employee ID Number.

First, The Data Files in the 'COBOL_Records' need to be put in to the following directory:
J:\COBOL

If not, the directories in 'ClockInOutUI, and ManagerOverrideUI in the 'working-storage-section' > 'WS-FILES-INPUT' needs 
to be changed to:

'J:\UW_Platteville_Fall_2022_Shared\ApplicationsInInformationSystems\PBS_Systems_ClockInOut\PBS_Systems_ClockInOut1192\PBS_Systems_ClockInOut\COBOL_Records\ . . .'

Launch the '.sln' file to launch the program. 

